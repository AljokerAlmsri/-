
 <!-- Footer -->
 <div class="footer py-4">
        <div class="container">
            <div class="social-links">
                <a href="#"><i class="fa-brands fa-facebook-square fa-2xl"></i></a>
                <a href="#"><i class="fa-brands fa-whatsapp-square fa-2xl"></i></a>
                <a href="#"><i class="fa-brands fa-instagram-square fa-2xl"></i></a>
                <a href="#"><i class="fa-brands fa-google-play fa-2xl"></i></a>
            </div>
            <span>جميع الحقوق محفوظة © 2022 - <a href="">احمد ناصر</a></span>
            <div class="site-links">
                <a href="#">صارحني</a> - 
                <a href="#">الخصوصية</a> - 
                <a href="#">القوانين</a> - 
                <a href="/saraha/call-us">اتصل بنا</a>
            </div>
        </div>
    </div>
</body>

<script src="./layout/js/proper.js"></script>
<script src="./layout/js/jquery.js"></script>
<script src="./layout/js/bootstrap.min.js"></script>
<script src="./layout/fonts/fontawesome/all.min.js"></script>
<script src="./layout/js/myjs.js"></script>
<script src="./layout/js/ajax-requests.js"></script>
</html>